-- SEQUENCE: alarm_notification_id_seq

-- DROP SEQUENCE alarm_notification_id_seq;

CREATE SEQUENCE alarm_notification_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 2147483647
    CACHE 1;

ALTER SEQUENCE alarm_notification_id_seq
    OWNER TO hippo;
	
	

-- SEQUENCE: alarm_record_id_seq

-- DROP SEQUENCE alarm_record_id_seq;

CREATE SEQUENCE alarm_record_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 2147483647
    CACHE 1;

ALTER SEQUENCE alarm_record_id_seq
    OWNER TO hippo;

-- SEQUENCE: config_id_seq

-- DROP SEQUENCE config_id_seq;

CREATE SEQUENCE config_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 2147483647
    CACHE 1;

ALTER SEQUENCE config_id_seq
    OWNER TO hippo;

-- SEQUENCE: hibernate_sequence

-- DROP SEQUENCE hibernate_sequence;

CREATE SEQUENCE hibernate_sequence
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE hibernate_sequence
    OWNER TO hippo;
	
	
-- SEQUENCE: synchronization_record_id_seq

-- DROP SEQUENCE synchronization_record_id_seq;

CREATE SEQUENCE synchronization_record_id_seq
    INCREMENT 1
    START 9000
    MINVALUE 9000
    MAXVALUE 2147483647
    CACHE 1;

ALTER SEQUENCE synchronization_record_id_seq
    OWNER TO hippo;


-- SEQUENCE: synchronization_records_id_seq

-- DROP SEQUENCE synchronization_records_id_seq;

CREATE SEQUENCE synchronization_records_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 2147483647
    CACHE 1;

ALTER SEQUENCE synchronization_records_id_seq
    OWNER TO hippo;


