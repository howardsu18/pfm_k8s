INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (1,'NOTIFICATION','webhook.error','https://demo.com/alarm-notification','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (2,'NOTIFICATION','kafka.servers','127.0.0.1:9092','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (3,'NOTIFICATION','kafka.topic','alarm-notification','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (4,'NOTIFICATION','kafka.username','admin','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (5,'NOTIFICATION','kafka.password','admin-sec','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (6,'NOTIFICATION','email.sender-email','noreply@lamtacloud.com','2021-02-18 15:22:13','2021-02-18 16:43:44.562457');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (7,'NOTIFICATION','email.password','Lamtacl0ud!','2021-02-18 15:22:13','2021-02-18 16:43:44.578582');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (8,'NOTIFICATION','email.smtp-server','smtpout.secureserver.net','2021-02-18 15:22:13','2021-02-18 16:43:44.578852');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (9,'NOTIFICATION','email.recipient-email','adam.xie@acentury.ca','2021-02-18 15:22:13','2021-02-19 05:38:38.735704');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (10,'NOTIFICATION','oam.servers','["https://nr.vdmf.fitdzone.com/oam?server=6","https://nr.vdmf.fitdzone.com/oam?server=110"]','2021-02-18 15:22:13','2021-03-29 14:09:45.796269');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (11,'NOTIFICATION','oam.username','oam_user','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (12,'NOTIFICATION','oam.password','password','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (13,'JOB_MTAS_HEARTBEAT_CHECK','mtas.servers','["https://nr.vdmf.fitdzone.com/mtas/health","https://www.omeracloud.com"]','2021-02-18 15:22:13','2021-02-26 02:46:53.255163');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (14,'JOB_MTAS_HEARTBEAT_CHECK','mtas.major-alarm-percentage','50','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (15,'JOB_MTAS_HEARTBEAT_CHECK','mtas.username','mtas_username','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (16,'JOB_MTAS_HEARTBEAT_CHECK','mtas.password','mtas_password','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (17,'JOB_REPORT','sftp.server','127.0.0.1:22','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (18,'JOB_REPORT','sftp.path','/report','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (19,'JOB_REPORT','sftp.username','sftp_username','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (20,'JOB_REPORT','sftp.private-key','-----BEGIN RSA PRIVATE KEY-----MIIEpAIBAAKCAQEA1XgIpZuqS/dj8sDXEz5+5uO3zegNUk/j528hm3BiHUHz5+7952evI0EjnHqV3vrWKErZO+LDTMrW3PDn5T483VlUMFYX9oibkXR/KP6HzqbtdsA0wwbyMz34FtvgITa5MiOuGCPD3i/n/6qcl5qJrAaAM3Ts5pQpeKxutHoufr+x5k69GUA0+M+pUyX9HXl9LZGDtMuwjb45SRy7WwpXH5llZRIzP0/YB9sqSW1QLpZ4mxObuugtrbl/9tcdXSHpyb3f2ZipOLXe4sMXkKuLjhuarLKHr422eZTFMgQ8pGZpL2bjoPHYT08WQ+gI1Hsvqj12GXQQPA1aTEDqj8JiQwIDAQABAoIBAB2+uBW7dyNWuYqd7Fo2HyC1ImuCpjiOAUfCaIBsTH+fLQlod+DCxdi3vuqS+kcz1JuQsmxx0JzmtsHan7WF0p1VUTHbDUPBDUxbW0yvCuV0xSoC5lc2pJEXVXZ59OUr5uphpmSetzBCpKUvdNp7IiviTALfjBMlGhJClLp5O/lVI3/oIU2pJfqJ2NqXvLyHTJ6reyY3l8v0IvocNyYg4PnruaHXYQcpSedOSKJZ+Jz//BqHkW8e4Hm81rk0gpBk6WoD0LbCmLRTGckxqRgYv5jw3AcZvhgd0vfT4ymEEB1i8N/CtfV51kKlhCwaCicZTjFE3vl4kMKXtOEl7wDRs+ECgYEA+Wl5+iHbsD1DZWpy+7kexEWKEhjqoxrB1m9Se/OCB/cQ82aO+dUIXxNGTRskTSkwNLKhqJ5uh0UQ09ehrKL6XNU8TZSlHDHRMDGrRyG5Ws80UAGXuia9df7V1l6nBOAPwY0OS9XcPV8YUL7kMy/+0Q8ThjZXT8GcNImoH6tr/q8CgYEA2xuCiLgUsJXgRSFPVn5eR0KhPU6nlXq5lbI6y0fo/jtaCOGqgKke9mptnnsF/DW2TCKmw/CfVo2DixjzZn9pUnOhc+vTKM9kkTFG2JHhRFJYhN3Z9NdPGaKVzvDDxiKrQIIQOAa+tZzLC3IAobFldUwGKOW0Sxk1np2gTR0Omq0CgYEAg0unTqnsQIa/p++1wBXfwGrrGEPNoTdAu2W3AlFaLl89qSRgN9yRn5tB8u1K2uPH4LX4rA9bGBKfnSVykrLpIV2PdTe/A2ymNryu8a8rKEbTvxpXiUNDkY4pe8QwIDzjjnx2/i0C17vrzPXwo5Gsjtlk6c5JgE7nsDCXNLTFETkCgYB4QrIz3m2kuq6c4vqL69JNZJnhb4F1/yVLr8areq28lNEHHO2brrfK4oGGQdn4I3cKdN55n2GlfQjdWPWHpZkmY0cTvDVrKeH1+0j6Z59wA46IZshRpbfJxz5YljeuUasTPhAu4Czeu8+KWalVFmwspGyhF+sMaSrQA45PpQo2BQKBgQCqMybTGMvqZU44AGVby4lf5vnnBpqtInmoAIyS74LHqsLkOQpkKAfi8OSVkjRivJ0EPEXhZ+2yhx89aVLCb79NY6rnGWHPu5LGxKPO9IvZ+BHdDVVSbcxwVX+TTvrAy+OGKle0/6j/Ic3L3OlJOTzppPiWfejTZJbT/3chiqxjtA==-----END RSA PRIVATE KEY-----','2021-02-18 15:22:13','2021-02-23 08:01:19.686637');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (21,'JOB_REPORT','sftp.password','sftp_password','2021-02-18 15:22:13','2021-02-23 08:00:35.980275');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (22,'JOB_REPORT','report.from','VDMF','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (23,'JOB_SYNCHRONIZATION_RECORD_INTERVAL_CHECK','min-interval-ms','60000','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (24,'JOB_SYNCHRONIZATION_RECORD_INTERVAL_CHECK','from','00:00','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (25,'JOB_SYNCHRONIZATION_RECORD_INTERVAL_CHECK','to','23:59','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (26,'JOB_ONENDS_HEARTBEAT_CHECK','onends.servers','["https://nr.vdmf.fitdzone.com/onends/health","https://www.omeracloud.com"]','2021-02-18 15:22:13','2021-02-24 03:03:53.027631');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (27,'JOB_ONENDS_HEARTBEAT_CHECK','onends.major-alarm-percentage','50','2021-02-18 18:52:25','2021-02-18 18:52:28');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (28,'JOB_ONENDS_HEARTBEAT_CHECK','onends.username','onends_username','2021-02-18 15:22:13','2021-02-19 08:03:50.921812');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (29,'JOB_ONENDS_HEARTBEAT_CHECK','onends.password','password','2021-02-18 15:22:13','2021-02-18 15:22:13');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (30,'JOBS','mtasHeartbeatCheckJob.disabled','false','2021-02-18 15:29:53','2021-02-23 06:16:42.783642');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (31,'JOBS','synchronizationRecordIntervalCheckJob.disabled','false','2021-02-18 15:30:22','2021-02-18 15:30:23');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (32,'JOBS','synchronizationRecordSuccessRateOfOneNDSToMTASCheckJob.disabled','false','2021-02-18 15:30:38','2021-02-25 02:39:58.990451');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (33,'JOBS','synchronizationRecordSuccessRateOfMTASToOneNDSCheckJob.disabled','false','2021-02-18 15:29:30','2021-02-23 06:16:54.885392');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (34,'JOBS','onendsHeartbeatCheckJob.disabled','false','2021-02-18 17:13:15','2021-02-25 02:38:58.514639');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (35,'JOBS','reportJob.disabled','false','2021-02-18 17:13:15','2021-02-18 17:13:15');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (36,'JOB_REPORT','sftp.auth-mode','password','2021-02-18 17:13:15','2021-02-23 08:01:24.555301');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (37,'JOBS','generateTrafficRecordJob.disabled','false','2021-02-18 17:13:15','2021-02-18 17:13:15');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (38,'RETRY_SETTING','retry.count','2','2021-03-11 11:47:02','2021-03-11 21:02:01.354058');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (39,'RETRY_SETTING','retry.interval','1000','2021-03-11 11:47:02','2021-03-11 21:02:19.349008');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (40,'NODE','node.name','vdmf','2021-03-19 17:35:09.431355','2021-03-19 17:35:09.431355');
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (41,'NODE','node.alias','vdmf','2021-03-19 17:35:20.125967','2021-03-19 17:35:20.125967');

INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") values (42, '2021-05-27 11:00:00.000', 'white.list.ips', '2021-05-27 11:00:00.000', 'SYNCHRONIZATION', '["127.0.0.1"]');

INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") VALUES (43, '2021-06-13 17:35:09.000', 'auditLogAlarmJob.disabled', '2021-06-13 17:35:09.000', 'JOBS', 'false');
INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") VALUES (44, '2021-06-13 17:35:09.000', 'suspectedIPLogAlarmJob.disabled', '2021-06-13 17:35:09.000', 'JOBS', 'false');
INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") VALUES (45, '2021-06-13 17:35:09.000', 'memUsageCheckJob.disabled', '2021-06-13 17:35:09.000', 'JOBS', 'false');
INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") VALUES (46, '2021-06-13 17:35:09.000', 'diskUsageCheckJob.disabled', '2021-06-13 17:35:09.000', 'JOBS', 'false');

INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") VALUES (47, '2021-06-14 20:24:09.000', 'cpuUsageCheckJob.disabled', '2021-06-14 20:24:09.000', 'JOBS', 'false');


INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") VALUES (48, '2021-06-16 18:52:09.000', 'cluster.name', '2021-06-16 18:52:09.000', 'CLUSTER', 'East');

INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") VALUES (49, '2021-06-22 13:37:09.000', 'sftp.servers', '2021-06-22 13:37:09.000', 'JOB_BACKUP', '[]');
INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") VALUES (50, '2021-06-22 13:37:09.000', 'backup.items', '2021-06-22 13:37:09.000', 'JOB_BACKUP', '[]');

--INSERT INTO config (id, creation_time, "key", last_modified_time, "namespace", value) VALUES (51, '2021-11-28 19:37:09.000', 'elasticsearch.servers', '2021-11-28 19:37:09.000', 'LOGS', '[{"server":"http://52.229.114.149:9200/?pretty","username":"elastic","password":"f6d29ad206864543a60be7debc87326f"}]');

--INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (52,'JOBS','backupServerStatusCheckJob.disabled','false','2021-11-28 19:37:09.000','2021-11-28 19:37:09.000');

--INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (53,'JOBS','elasticsearchServerStatusCheckJob.disabled','false','2021-11-28 19:37:09.000','2021-11-28 19:37:09.000');

INSERT INTO config ("id","creation_time", "key", "last_modified_time", "namespace", value) VALUES (51,'2021-11-28 19:37:09.000', 'elasticsearch.servers', '2021-11-28 19:37:09.000', 'LOGS', '[{"server":"http://172.21.103.22:9200/?pretty","username":"elastic","password":"f6d29ad206864543a60be7debc87326f"}, {"server":"http://172.21.103.23:9200/?pretty","username":"elastic","password":"f6d29ad206864543a60be7debc87326f"}, {"server":"http://172.21.103.24:9200/?pretty","username":"elastic","password":"f6d29ad206864543a60be7debc87326f"}]');
 
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (52,'JOBS','backupServerStatusCheckJob.disabled','false','2021-11-28 19:37:09.000','2021-11-28 19:37:09.000');
 
INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (53,'JOBS','elasticsearchServerStatusCheckJob.disabled','false','2021-11-28 19:37:09.000','2021-11-28 19:37:09.000');

INSERT INTO config ("id", "creation_time", "key", "last_modified_time", "namespace", "value") VALUES (54, '2021-12-07 19:39:09.000', 'backup.sftp.servers', '2021-12-07 19:39:09.000', 'LOGS', '[{"server":"192.168.1.16:2222","path":"/data","username":"vdmf","password":"pass","authMode":"password"}]');

INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (55,'JOBS','vdmfActiveStatusReportJob.disabled','false','2021-12-07 19:39:09.000','2021-12-07 19:39:09.000');

INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (56,'JOBS','auditLogBackupJob.disabled','true','2021-12-09 19:39:09.000','2021-12-09 19:39:09.000');

INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (57,'JOBS','dmfConfigurationBackupJob.disabled','true','2021-12-09 19:39:09.000','2021-12-09 19:39:09.000');

INSERT INTO config ("id","namespace","key","value","creation_time","last_modified_time") VALUES (58,'JOBS','splunkBackupJob.disabled','true','2021-12-09 19:39:09.000','2021-12-09 19:39:09.000');



