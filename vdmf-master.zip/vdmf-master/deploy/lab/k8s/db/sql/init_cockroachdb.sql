

CREATE DATABASE vdmf;
CREATE USER postgres;
GRANT ALL ON DATABASE vdmf TO postgres;

USE vdmf;

SET CLUSTER SETTING sql.defaults.serial_normalization = sql_sequence;

-- Table: alarm_notification

DROP TABLE alarm_notification;

CREATE TABLE alarm_notification
(
	id serial NOT NULL,
	alarm_record_id int4 NULL,
	alarm_record_status varchar(255) NULL,
	creation_time timestamp NULL,
	details varchar(2048) NULL,
	is_success bool NULL,
	job_name varchar(255) NULL,
	target varchar(255) NULL,
	"type" varchar(255) NULL,
	alarm_record_reason varchar(255) NULL,
	results varchar(2048) NULL,
	success bool NOT NULL,
	node varchar(255) NOT NULL,
	node_alias varchar(255) NOT NULL,
	alert_key uuid NOT NULL,
	cleared bool NOT NULL,
	updated_at timestamp NULL,
	CONSTRAINT alarm_notification_pkey PRIMARY KEY (id)
);

	

-- Table: alarm_record

DROP TABLE alarm_record;

CREATE TABLE alarm_record
(
	id serial NOT NULL,
	complete_time timestamp NULL,
	details varchar(2048) NULL,
	job_name varchar(255) NULL,
	start_time timestamp NULL,
	status varchar(255) NULL,
	reason varchar(255) NULL,
	changed bool NULL,
	update_time timestamp NULL,
	CONSTRAINT alarm_record_pkey PRIMARY KEY (id)
);


-- Table: config

DROP TABLE config;

CREATE TABLE config
(
	id serial NOT NULL,
	"namespace" varchar(255) NOT NULL,
	"key" varchar(255) NOT NULL,
	value varchar(4096) NULL,
	creation_time timestamp NOT NULL,
	last_modified_time timestamp NULL,
	CONSTRAINT config_pkey PRIMARY KEY (id)
);



-- Table: cpu_usage

DROP TABLE cpu_usage;

CREATE TABLE cpu_usage
(
	id int4 NOT NULL,
	"date" timestamp NULL,
	"instance" varchar(255) NULL,
	"usage" float4 NULL,
	CONSTRAINT cpu_usage_pkey PRIMARY KEY (id)
);



-- Table: disk_usage

DROP TABLE disk_usage;

CREATE TABLE disk_usage
(
	id int4 NOT NULL,
	"date" timestamp NULL,
	"instance" varchar(255) NULL,
	"usage" float4 NULL,
	CONSTRAINT disk_usage_pkey PRIMARY KEY (id)
);


-- Table: job_execution_log

DROP TABLE job_execution_log;

CREATE TABLE job_execution_log (
	id varchar(40) NOT NULL,
	job_name varchar(100) NOT NULL,
	task_id varchar(255) NOT NULL,
	hostname varchar(255) NOT NULL,
	ip varchar(50) NOT NULL,
	sharding_item int4 NOT NULL,
	execution_source varchar(20) NOT NULL,
	failure_cause varchar(4000) NULL,
	is_success bool NOT NULL,
	start_time timestamp NULL,
	complete_time timestamp NULL,
	CONSTRAINT job_execution_log_pkey PRIMARY KEY (id)
);


-- Table: job_status_trace_log

DROP TABLE job_status_trace_log;

CREATE TABLE job_status_trace_log (
	id varchar(40) NOT NULL,
	job_name varchar(100) NOT NULL,
	original_task_id varchar(255) NOT NULL,
	task_id varchar(255) NOT NULL,
	slave_id varchar(50) NOT NULL,
	"source" varchar(50) NOT NULL,
	execution_type varchar(20) NOT NULL,
	sharding_item varchar(100) NOT NULL,
	state varchar(20) NOT NULL,
	message varchar(4000) NULL,
	creation_time timestamp NULL,
	CONSTRAINT job_status_trace_log_pkey PRIMARY KEY (id)
);

-- Index: task_id_state_index

DROP INDEX task_id_state_index;

CREATE INDEX task_id_state_index ON job_status_trace_log USING btree (task_id, state);



-- Table: memory_usage

DROP TABLE memory_usage;

CREATE TABLE memory_usage (
	id int4 NOT NULL,
	"date" timestamp NULL,
	"instance" varchar(255) NULL,
	"usage" float4 NULL,
	CONSTRAINT memory_usage_pkey PRIMARY KEY (id)
);


-- Table: synchronization_record

DROP TABLE synchronization_record;

-- CREATE TABLE synchronization_record (
-- 	id serial NOT NULL,
-- 	"case" int4 NULL,
-- 	accepted_at timestamp NULL,
-- 	accepted_from varchar(255) NULL,
-- 	"action" int4 NULL,
-- 	basicmsisdn varchar(255) NULL,
-- 	details text NULL,
-- 	errorcode varchar(255) NULL,
-- 	message varchar(255) NULL,
-- 	"procedure" varchar(255) NULL,
-- 	"result" int4 NULL,
-- 	status int4 NULL,
-- 	"type" int4 NULL,
-- 	update_at timestamp NULL,
-- 	"version" int4 NOT NULL,
-- 	CONSTRAINT synchronization_record_pkey PRIMARY KEY (id)
-- );
CREATE TABLE synchronization_record (
	id serial NOT NULL,
	"case" int4 NULL,
	accepted_at timestamp NULL,
	accepted_from varchar(255) NULL,
	basicmsisdn varchar(255) NULL,
	cfb varchar(255) NULL,
	cfnrc varchar(255) NULL,
	cfnry varchar(255) NULL,
	cfu varchar(255) NULL,
	details text NULL,
	errorcode varchar(255) NULL,
	hashcode varchar(255) NULL,
	message varchar(255) NULL,
	"procedure" varchar(255) NULL,
	"result" int4 NULL,
	status int4 NULL,
	update_at timestamp NULL,
	"version" int4 NOT NULL,
	CONSTRAINT synchronization_record_pkey PRIMARY KEY (id)
);


-- Table: traffic_record

DROP TABLE traffic_record;

CREATE TABLE traffic_record (
	id int4 NOT NULL,
	cfb_activate int4 NULL,
	cfb_deactivate int4 NULL,
	cfnrc_activate int4 NULL,
	cfnrc_deactivate int4 NULL,
	cfnry_activate int4 NULL,
	cfnry_deactivate int4 NULL,
	cfu_activate int4 NULL,
	cfu_deactivate int4 NULL,
	cs_to_volte int4 NULL,
	"date" timestamp NULL,
	failure int4 NULL,
	"instance" varchar(255) NULL,
	missing_ims int4 NULL,
	period_end timestamp NULL,
	period_start timestamp NULL,
	"skip" int4 NULL,
	success int4 NULL,
	total int4 NULL,
	volte_tocs int4 NULL,
	success_rate float4 NULL,
	cfb_activate_failure int4 NULL,
	cfb_activate_success int4 NULL,
	cfb_deactivate_failure int4 NULL,
	cfb_deactivate_success int4 NULL,
	cfnrc_activate_failure int4 NULL,
	cfnrc_activate_success int4 NULL,
	cfnrc_deactivate_failure int4 NULL,
	cfnrc_deactivate_success int4 NULL,
	cfnry_activate_failure int4 NULL,
	cfnry_activate_success int4 NULL,
	cfnry_deactivate_failure int4 NULL,
	cfnry_deactivate_success int4 NULL,
	cfu_activate_failure int4 NULL,
	cfu_activate_success int4 NULL,
	cfu_deactivate_failure int4 NULL,
	cfu_deactivate_success int4 NULL,
	cs_to_volte_failure int4 NULL,
	cs_to_volte_success int4 NULL,
	volte_tocsfailure int4 NULL,
	volte_tocssuccess int4 NULL,
	CONSTRAINT traffic_record_pkey PRIMARY KEY (id)
);



-- Table: users

DROP TABLE users;

CREATE TABLE users (
	id int4 NOT NULL,
	creation_time timestamp NULL,
	email varchar(255) NULL,
	error_count int4 NULL DEFAULT 0,
	last_modified_time timestamp NULL,
	"locked" bool NULL,
	"password" varchar(255) NULL,
	user_id uuid NOT NULL,
	user_role varchar(255) NOT NULL,
	username varchar(255) NOT NULL,
	is_temporary_password bool NULL,
	last_login_time timestamp NULL,
	last_modified_password_time timestamp NULL,
	max_age int4 NULL,
	CONSTRAINT uk_6dotkott2kjsp8vw4d0m25fb7 UNIQUE (email),
	CONSTRAINT uk_6efs5vmce86ymf5q7lmvn2uuf UNIQUE (user_id),
	CONSTRAINT uk_r43af9ap4edm43mmtq01oddj6 UNIQUE (username),
	CONSTRAINT users_pkey PRIMARY KEY (id)
);

	

-- Table audit_log added at 2021-06-04

DROP TABLE audit_log;

CREATE TABLE audit_log (
	id SERIAL4,
	creation_time timestamp NULL,
	details text NULL,
	"method" varchar(255) NULL,
	"path" varchar(255) NULL,
	source_ip varchar(255) NULL,
	userid varchar(255) NULL,
	username varchar(255) NULL,
	message varchar(255) NULL,
	CONSTRAINT audit_log_pkey PRIMARY KEY (id)
);


-- Table suspected_ip_log added at 2021-06-15
DROP TABLE suspected_ip_log;

CREATE TABLE suspected_ip_log (
	--id int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY,
	id serial NOT NULL,
	creation_time timestamp NULL,
	details text NULL,
	message varchar(255) NULL,
	source_ip varchar(255) NULL,
	CONSTRAINT suspected_ip_log_pkey PRIMARY KEY (id)
);


-- Table cease_alarm_record added at 2021-06-18
DROP TABLE cease_alarm_record;

CREATE TABLE cease_alarm_record (
	--id int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY,
	id serial NOT NULL,
	alarm_record_id int4 NOT NULL,
	changed bool NULL,
	complete_time timestamp NULL,
	details varchar(2048) NULL,
	job_name varchar(255) NOT NULL,
	reason varchar(255) NULL,
	sent bool NULL,
	start_time timestamp NULL,
	status varchar(255) NOT NULL,
	update_time timestamp NULL,
	cease_time timestamp NULL,
	CONSTRAINT cease_alarm_record_pkey PRIMARY KEY (id)
);


-- Table backup_log added at 2021-06-28
DROP TABLE backup_log;

CREATE TABLE backup_log (
	--id int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY,
	id serial NOT NULL,
	backup_time timestamp NULL,
	cleanup_time timestamp NULL,
	details varchar(2048) NULL,
	end_time timestamp NULL,
	"path" varchar(255) NULL,
	reason varchar(255) NULL,
	retention_days int4 NULL,
	start_time timestamp NULL,
	status varchar(255) NOT NULL,
	time_freq varchar(255) NULL,
	time_value varchar(255) NULL,
	"type" varchar(255) NOT NULL,
	hash varchar(255) NULL,
	length int4 NULL,
	row_count int4 NULL,
	CONSTRAINT backup_log_pkey PRIMARY KEY (id)
);


