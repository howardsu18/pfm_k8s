#！/bin/bash
######################################################
# $Name:        clean_es_index.sh
# $Version:     v1.0
# $Function:    clean es log index
# $Author:      Howard Su
# $Create Date: 2021-08-26
# $Description: shell
######################################################
# log path
CLEAN_LOG="/home/howard/clean_es_index.log"

# index prefix
INDEX_PRFIX="logstash-"

# elasticsearch ip and  port
SERVER_PORT=127.0.0.1:9200

# get indexes name list 
INDEXS=$(curl -s "${SERVER_PORT}/_cat/indices?v" |grep "${INDEX_PRFIX}"|awk '{print $3}')

# setting how many date index that will be delete . if setting 30, then before 30 days index will be delete
DELTIME=30

# seconds since 1970-01-01 00:00:00 seconds
SECONDS=$(date -d  "$(date  +%F) -${DELTIME} days" +%s)

# check log file, if don't exist then create it
if [ ! -f  "${CLEAN_LOG}" ]
then
touch "${CLEAN_LOG}"
fi

# delete indexes
echo "----------------------------clean time is $(date +%Y-%m-%d_%H:%M:%S) ------------------------------" >>${CLEAN_LOG}
for del_index in ${INDEXS}
do
    indexDate=$( echo ${del_index} |cut -d "-" -f 2 )
    format_date=$(echo ${indexDate}| sed 's/\.//g')

    #format_date=$(echo ${indexDate}| sed 's/-//g')

    indexSecond=$( date -d ${format_date} +%s )

    if [ $(( ${SECONDS}- ${indexSecond} )) -gt 0 ]
        then
        echo "${del_index}" >> ${CLEAN_LOG}
        # delete index and get result
        delResult=`curl -s  -XDELETE "${SERVER_PORT}/"${del_index}"?pretty" |sed -n '2p'`
        # write result to log file
        echo "clean time is $(date)" >>${CLEAN_LOG}
        echo "delResult is ${delResult}" >>${CLEAN_LOG}
    fi
done
